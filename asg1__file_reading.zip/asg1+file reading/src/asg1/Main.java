package asg1;

import java.util.*;
import java.lang.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.io.PrintWriter;   // Import the FileWriter class
import java.io.FileWriter;
import java.io.FileReader;
import java.util.Arrays;
import java.util.ArrayList;


class MergeSort extends Thread
{
	
	public static void mergeSort(int[] unsortedArray, int length) throws IOException
	 {
		if(length < 2)
			return;
		int middle = length/2;
		int leftCount = 0;
		int rightCount = middle;
		int[] leftArray = new int[middle];
		int[] rightArray = new int[length-middle];
		
		for(leftCount = 0; leftCount < middle; leftCount++)
			leftArray[leftCount] = unsortedArray[leftCount];
		
		for(rightCount = middle; rightCount < length; rightCount++)
			rightArray[rightCount - middle] = unsortedArray[rightCount];
		
		Thread left = new Thread() //creates the threads to be used for the left side of the sorts 
		{
			public void run()
			{
				try {
					mergeSort(leftArray, middle);
				} catch (IOException e) {
					//  catch block
					e.printStackTrace();
				}				
			}
			
		};
		Thread right = new Thread()//creates the threads to be used for the right side of the sorts 
		{
			public void run()
			{
				try {
					mergeSort(rightArray, length- middle);
				} catch (IOException e) {
					//  catch block
					e.printStackTrace();
				}				
			}
		};
		
		FileWriter fw = new FileWriter("output.txt",true);  // creates file 
        PrintWriter out = new PrintWriter(fw);


		left.start();
		out.println("Left Thread " + left.currentThread().getId() + " : Started ");  //starts and stores the left merge sort part in the text file 
		right.start();
		out.println("Right Thread " + right.currentThread().getId() + " : Started ");//starts and stores the right merge sort part in the text file	
		
		try {
			left.join();
			out.println("Left Thread " + left.currentThread().getId() + " : Finished : " + Arrays.toString(leftArray)); // finishes the left side of the sort and closes the left thread
			right.join();
			out.println("Right Thread " + right.currentThread().getId()+ " : Finished : " + Arrays.toString(rightArray)); //finishes the right side of the sort and closes the right thread
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}		
		merge(unsortedArray, leftArray, rightArray, middle, length-middle);
		out.close();
	}
	
	public static void merge(int[] unsortedArray, int[] leftArray, int[] rightArray, int l, int r) //sorting algorithm 
	{
		int i = 0, j = 0, k = 0;
		
		while(i < l && j < r)
		{
			if(leftArray[i] <= rightArray[j])
				unsortedArray[k++] = leftArray[i++];
			else
				unsortedArray[k++] = rightArray[j++];
		}
		while(i < l)
			unsortedArray[k++] = leftArray[i++];
		while(j < r)
			unsortedArray[k++] = rightArray[j++];
	}
		
}




class ReadingFiles 
{
		
	public static int [] readFiles(String file){  //reads chosen file 
		try{
			File f = new File(file);				//scans the file first to see how long it is 
			Scanner s = new Scanner(f);				// using a counter 
			int ctr = 0;
			while(s.hasNextInt()){
				ctr++;								
				s.nextInt();
			}
			int [] arr = new int [ctr];			//sets size of array to that of the counter
			Scanner s1 = new Scanner(f);
			for (int i = 0; i <arr.length; i++)
			arr[i]=s1.nextInt();				//stores values into array 
			return arr;

		}

		catch (Exception e ){return null;}
	}
}







public class Main
{	
	public static void main(String[] args) throws IOException
	{	
		   
		
		int [] unsortedArray = ReadingFiles.readFiles("input.txt"); //reads file and stores the values in an array
		System.out.println(Arrays.toString(unsortedArray));

		FileWriter fw = new FileWriter("output.txt",true);	// creates output file to write in append mode 
        PrintWriter out = new PrintWriter(fw);
			
		MergeSort.mergeSort(unsortedArray, unsortedArray.length); // sorting algo  and threads
		
		out.println("~~~~~~~~~~~ SORTED ARRAY ~~~~~~~~~~~"); 
		out.println(Arrays.toString(unsortedArray)); // final sorted array

		out.close();
	}
}

