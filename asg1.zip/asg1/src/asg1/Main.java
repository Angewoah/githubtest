package asg1;

import java.util.*;
import java.lang.*;


class MergeSort extends Thread
{
	
	public static void mergeSort(int[] unsortedArray, int length) {
		if(length < 2)
			return;
		int middle = length/2;
		int leftCount = 0;
		int rightCount = middle;
		int[] leftArray = new int[middle];
		int[] rightArray = new int[length-middle];
		
		for(leftCount = 0; leftCount < middle; leftCount++)
			leftArray[leftCount] = unsortedArray[leftCount];
		
		for(rightCount = middle; rightCount < length; rightCount++)
			rightArray[rightCount - middle] = unsortedArray[rightCount];
		
		Thread left = new Thread()
		{
			public void run()
			{
				mergeSort(leftArray, middle);				
			}
			
		};
		Thread right = new Thread()
		{
			public void run()
			{
				mergeSort(rightArray, length- middle);				
			}
		};
		
		left.start();
		System.out.println("Left Thread " + left.currentThread().getId() + " : Started ");
		right.start();
		System.out.println("Right Thread " + right.currentThread().getId() + " : Started ");

		try {
			left.join();
			System.out.println("Left Thread " + left.currentThread().getId() + " : Finished : " + Arrays.toString(leftArray));
			right.join();
			System.out.println("Right Thread " + right.currentThread().getId()+ " : Finished : " + Arrays.toString(rightArray));
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}		
		merge(unsortedArray, leftArray, rightArray, middle, length-middle);
	}
	
	public static void merge(int[] unsortedArray, int[] leftArray, int[] rightArray, int l, int r)
	{
		int i = 0, j = 0, k = 0;
		
		while(i < l && j < r)
		{
			if(leftArray[i] <= rightArray[j])
				unsortedArray[k++] = leftArray[i++];
			else
				unsortedArray[k++] = rightArray[j++];
		}
		while(i < l)
			unsortedArray[k++] = leftArray[i++];
		while(j < r)
			unsortedArray[k++] = rightArray[j++];
	}
		
}

public class Main
{	
	public static void main(String[] args)
	{
		int[] unsortedArray = new int[]{3304, 8221, 26849, 14038, 1509, 6367, 7856, 21362};

		MergeSort.mergeSort(unsortedArray, unsortedArray.length);

		System.out.println("~~~~~~~~~~~ SORTED ARRAY ~~~~~~~~~~~");
		System.out.println(Arrays.toString(unsortedArray));
	}
}

